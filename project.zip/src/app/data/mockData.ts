export const rideOptions = [
  {
    id: 'uberx',
    name: 'UberX',
    description: 'Affordable, everyday rides',
    passengers: 4,
    eta: '3 min',
    price: 12.50,
    multiplier: null
  },
  {
    id: 'comfort',
    name: 'Comfort',
    description: 'Newer cars with extra legroom',
    passengers: 4,
    eta: '5 min',
    price: 15.75,
    multiplier: null
  },
  {
    id: 'uberxl',
    name: 'UberXL',
    description: 'Affordable rides for groups up to 6',
    passengers: 6,
    eta: '4 min',
    price: 18.25,
    multiplier: null
  },
  {
    id: 'black',
    name: 'Black',
    description: 'Premium rides in luxury cars',
    passengers: 4,
    eta: '8 min',
    price: 28.50,
    multiplier: null
  }
];

export const driverInfo = {
  name: 'Michael Rodriguez',
  rating: 4.95,
  trips: 1247,
  carModel: 'Toyota Camry',
  carColor: 'Silver',
  licensePlate: 'ABC 1234',
  photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop'
};

export const services = [
  {
    id: 'ride',
    name: 'Ride',
    description: 'Go anywhere'
  },
  {
    id: 'food',
    name: 'Food',
    description: 'Order delivery'
  },
  {
    id: 'package',
    name: 'Package',
    description: 'Send things'
  }
];
