import React from 'react';
import { Menu, User } from 'lucide-react';
import { useNavigate } from 'react-router';
import { SearchBar } from '../components/molecules/SearchBar';
import { ServiceCard } from '../components/molecules/ServiceCard';
import { BottomNav } from '../components/molecules/BottomNav';
import { IconButton } from '../components/atoms/IconButton';
import { services } from '../data/mockData';

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="h-screen w-full bg-white flex flex-col font-['Inter']">
      {/* Map Background */}
      <div className="flex-1 relative bg-gradient-to-br from-gray-100 to-gray-200">
        {/* Simulated Map */}
        <div className="absolute inset-0 opacity-30">
          <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="gray" strokeWidth="0.5"/>
            </pattern>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        {/* Map location marker */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-full">
          <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center shadow-lg">
            <div className="w-3 h-3 bg-white rounded-full"></div>
          </div>
        </div>

        {/* Top Bar */}
        <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between">
          <IconButton variant="light">
            <Menu size={24} />
          </IconButton>
          <IconButton variant="light">
            <User size={24} />
          </IconButton>
        </div>
      </div>

      {/* Bottom Sheet */}
      <div className="bg-white rounded-t-3xl shadow-2xl p-6 pb-24 max-w-md mx-auto w-full">
        {/* Search Bar */}
        <div className="mb-6">
          <SearchBar />
        </div>

        {/* Promo Banner */}
        <div className="mb-6 bg-gradient-to-r from-black to-gray-800 rounded-2xl p-4 text-white">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <p className="text-xs text-gray-300 mb-1">Limited Time Offer</p>
              <p className="mb-1">Save 20% on your next ride</p>
              <p className="text-xs text-gray-300">Use code: UBER20</p>
            </div>
            <div className="text-4xl">🎉</div>
          </div>
        </div>

        {/* Suggestions */}
        <div className="mb-6">
          <h3 className="text-sm text-gray-600 mb-3">Suggestions</h3>
          <div className="space-y-3">
            <button 
              onClick={() => navigate('/ride-selection')}
              className="w-full flex items-center gap-3 text-left hover:bg-gray-50 rounded-lg p-2 -m-2 transition-colors"
            >
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                <div className="w-2 h-2 bg-black rounded-full"></div>
              </div>
              <div>
                <p className="text-black">Home</p>
                <p className="text-sm text-gray-500">123 Main Street</p>
              </div>
            </button>
            <button 
              onClick={() => navigate('/ride-selection')}
              className="w-full flex items-center gap-3 text-left hover:bg-gray-50 rounded-lg p-2 -m-2 transition-colors"
            >
              <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                <div className="w-2 h-2 bg-black rounded-full"></div>
              </div>
              <div>
                <p className="text-black">Work</p>
                <p className="text-sm text-gray-500">456 Office Plaza</p>
              </div>
            </button>
          </div>
        </div>

        {/* Services */}
        <div>
          <h3 className="text-sm text-gray-600 mb-3">Services</h3>
          <div className="grid grid-cols-3 gap-3">
            {services.map((service) => (
              <ServiceCard key={service.id} {...service} />
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  );
}