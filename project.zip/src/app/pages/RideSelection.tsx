import React, { useState } from 'react';
import { ArrowLeft, MapPin } from 'lucide-react';
import { useNavigate } from 'react-router';
import { RideOptionCard } from '../components/molecules/RideOptionCard';
import { PrimaryButton } from '../components/atoms/PrimaryButton';
import { IconButton } from '../components/atoms/IconButton';
import { rideOptions } from '../data/mockData';

export default function RideSelection() {
  const navigate = useNavigate();
  const [selectedRide, setSelectedRide] = useState('uberx');

  const handleConfirm = () => {
    navigate('/active-ride');
  };

  return (
    <div className="h-screen w-full bg-white flex flex-col font-['Inter']">
      {/* Map Background - Smaller */}
      <div className="h-[45vh] relative bg-gradient-to-br from-gray-100 to-gray-200">
        {/* Simulated Map with route */}
        <div className="absolute inset-0 opacity-30">
          <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <pattern id="grid2" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="gray" strokeWidth="0.5"/>
            </pattern>
            <rect width="100%" height="100%" fill="url(#grid2)" />
          </svg>
        </div>

        {/* Route line visualization */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <path
            d="M 50 80 Q 120 150, 300 200"
            stroke="black"
            strokeWidth="3"
            fill="none"
            strokeDasharray="8,4"
          />
        </svg>

        {/* Start and End markers */}
        <div className="absolute" style={{ top: '20%', left: '15%' }}>
          <div className="w-3 h-3 bg-black rounded-full"></div>
        </div>
        <div className="absolute" style={{ top: '55%', right: '20%' }}>
          <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center shadow-lg">
            <MapPin size={20} className="text-white" />
          </div>
        </div>

        {/* Top Bar */}
        <div className="absolute top-0 left-0 right-0 p-4">
          <IconButton variant="light" onClick={() => navigate('/')}>
            <ArrowLeft size={24} />
          </IconButton>
        </div>

        {/* Route Info */}
        <div className="absolute bottom-4 left-4 right-4 bg-white rounded-xl p-3 shadow-lg">
          <div className="flex items-start gap-3">
            <div className="flex flex-col items-center gap-2">
              <div className="w-2 h-2 bg-black rounded-full"></div>
              <div className="w-0.5 h-8 bg-gray-300"></div>
              <MapPin size={16} className="text-black" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-600">Current Location</p>
              <p className="text-black mb-3">123 Main Street</p>
              <p className="text-sm text-gray-600">Destination</p>
              <p className="text-black">Downtown Convention Center</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-500">12 min</p>
              <p className="text-xs text-gray-500">4.2 mi</p>
            </div>
          </div>
        </div>
      </div>

      {/* Ride Options */}
      <div className="flex-1 bg-white rounded-t-3xl -mt-6 shadow-2xl p-6 overflow-y-auto max-w-md mx-auto w-full">
        <h2 className="text-black mb-4">Choose a ride</h2>
        
        <div className="space-y-3 mb-6">
          {rideOptions.map((option) => (
            <RideOptionCard
              key={option.id}
              {...option}
              isSelected={selectedRide === option.id}
              onClick={() => setSelectedRide(option.id)}
            />
          ))}
        </div>

        {/* Payment Method */}
        <div className="mb-6 p-4 bg-gray-50 rounded-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                <span className="text-lg">💳</span>
              </div>
              <div>
                <p className="text-sm text-gray-600">Payment</p>
                <p className="text-black">•••• 4242</p>
              </div>
            </div>
            <button className="text-sm text-gray-600 underline">Change</button>
          </div>
        </div>

        {/* Schedule for later option */}
        <div className="mb-6">
          <button className="w-full p-4 bg-gray-50 rounded-xl flex items-center justify-between hover:bg-gray-100 transition-colors">
            <div className="flex items-center gap-3">
              <span className="text-xl">⏰</span>
              <div className="text-left">
                <p className="text-black">Schedule for later</p>
                <p className="text-sm text-gray-600">Plan your ride in advance</p>
              </div>
            </div>
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>

        {/* Confirm Button */}
        <PrimaryButton onClick={handleConfirm}>
          Confirm {rideOptions.find(r => r.id === selectedRide)?.name}
        </PrimaryButton>
      </div>
    </div>
  );
}