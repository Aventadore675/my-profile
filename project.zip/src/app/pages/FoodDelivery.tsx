import React, { useState } from 'react';
import { ArrowLeft, Search, Star, Clock, DollarSign } from 'lucide-react';
import { useNavigate } from 'react-router';
import { IconButton } from '../components/atoms/IconButton';
import { BottomNav } from '../components/molecules/BottomNav';

interface Restaurant {
  id: string;
  name: string;
  cuisine: string;
  rating: number;
  deliveryTime: string;
  deliveryFee: number;
  image: string;
}

const restaurants: Restaurant[] = [
  {
    id: '1',
    name: 'The Burger Place',
    cuisine: 'American, Burgers',
    rating: 4.8,
    deliveryTime: '20-30 min',
    deliveryFee: 2.99,
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop'
  },
  {
    id: '2',
    name: 'Sushi Paradise',
    cuisine: 'Japanese, Sushi',
    rating: 4.9,
    deliveryTime: '25-35 min',
    deliveryFee: 3.49,
    image: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=400&h=300&fit=crop'
  },
  {
    id: '3',
    name: 'Pizza Perfect',
    cuisine: 'Italian, Pizza',
    rating: 4.7,
    deliveryTime: '15-25 min',
    deliveryFee: 1.99,
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop'
  },
  {
    id: '4',
    name: 'Thai Spice',
    cuisine: 'Thai, Asian',
    rating: 4.6,
    deliveryTime: '30-40 min',
    deliveryFee: 2.49,
    image: 'https://images.unsplash.com/photo-1559314809-0d155014e29e?w=400&h=300&fit=crop'
  },
  {
    id: '5',
    name: 'Taco Fiesta',
    cuisine: 'Mexican, Tacos',
    rating: 4.8,
    deliveryTime: '20-30 min',
    deliveryFee: 2.99,
    image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=400&h=300&fit=crop'
  },
  {
    id: '6',
    name: 'Healthy Bowls',
    cuisine: 'Healthy, Salads',
    rating: 4.5,
    deliveryTime: '25-35 min',
    deliveryFee: 3.99,
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop'
  }
];

const categories = [
  { id: 'all', name: 'All', icon: '🍽️' },
  { id: 'burgers', name: 'Burgers', icon: '🍔' },
  { id: 'pizza', name: 'Pizza', icon: '🍕' },
  { id: 'sushi', name: 'Sushi', icon: '🍱' },
  { id: 'mexican', name: 'Mexican', icon: '🌮' },
  { id: 'healthy', name: 'Healthy', icon: '🥗' }
];

export default function FoodDelivery() {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('all');

  return (
    <div className="h-screen w-full bg-white flex flex-col font-['Inter']">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="p-4 max-w-md mx-auto w-full">
          <div className="flex items-center gap-4 mb-4">
            <IconButton variant="light" onClick={() => navigate('/')}>
              <ArrowLeft size={24} />
            </IconButton>
            <div>
              <h1 className="text-xl text-black">Food Delivery</h1>
              <p className="text-sm text-gray-600">123 Main Street</p>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search for food or restaurants"
              className="w-full bg-gray-50 rounded-full pl-12 pr-4 py-3 text-black placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-black"
            />
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="bg-white border-b border-gray-100 sticky top-[136px] z-10">
        <div className="max-w-md mx-auto w-full px-4 py-3">
          <div className="flex gap-3 overflow-x-auto scrollbar-hide">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`flex-shrink-0 px-4 py-2 rounded-full transition-all ${
                  selectedCategory === category.id
                    ? 'bg-black text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <span className="mr-2">{category.icon}</span>
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Restaurant List */}
      <div className="flex-1 overflow-y-auto pb-24">
        <div className="max-w-md mx-auto w-full p-4">
          <h2 className="text-lg text-black mb-4">Restaurants near you</h2>
          
          <div className="space-y-4">
            {restaurants.map((restaurant) => (
              <button
                key={restaurant.id}
                onClick={() => navigate('/restaurant-detail')}
                className="w-full bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden text-left transition-all hover:shadow-md active:scale-[0.99]"
              >
                {/* Restaurant Image */}
                <div className="relative h-40 bg-gray-200">
                  <img
                    src={restaurant.image}
                    alt={restaurant.name}
                    className="w-full h-full object-cover"
                  />
                  {/* Delivery Fee Badge */}
                  <div className="absolute top-3 right-3 bg-white rounded-full px-3 py-1 shadow-md">
                    <p className="text-xs text-black">${restaurant.deliveryFee.toFixed(2)} delivery</p>
                  </div>
                </div>

                {/* Restaurant Info */}
                <div className="p-4">
                  <h3 className="text-black mb-1">{restaurant.name}</h3>
                  <p className="text-sm text-gray-600 mb-3">{restaurant.cuisine}</p>
                  
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <Star size={16} className="text-black fill-black" />
                      <span className="text-black">{restaurant.rating}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock size={16} className="text-gray-600" />
                      <span className="text-gray-600">{restaurant.deliveryTime}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <DollarSign size={16} className="text-gray-600" />
                      <span className="text-gray-600">{restaurant.deliveryFee.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  );
}