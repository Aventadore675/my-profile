import React from 'react';
import { ArrowLeft, Shield, MoreVertical, Navigation } from 'lucide-react';
import { useNavigate } from 'react-router';
import { DriverCard } from '../components/molecules/DriverCard';
import { IconButton } from '../components/atoms/IconButton';
import { driverInfo } from '../data/mockData';

export default function ActiveRide() {
  const navigate = useNavigate();

  return (
    <div className="h-screen w-full bg-white flex flex-col font-['Inter']">
      {/* Full Map Background */}
      <div className="flex-1 relative bg-gradient-to-br from-gray-100 to-gray-200">
        {/* Simulated Map */}
        <div className="absolute inset-0 opacity-30">
          <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <pattern id="grid3" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="gray" strokeWidth="0.5"/>
            </pattern>
            <rect width="100%" height="100%" fill="url(#grid3)" />
          </svg>
        </div>

        {/* Route visualization */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <path
            d="M 100 150 Q 180 250, 280 350 Q 320 400, 350 500"
            stroke="black"
            strokeWidth="4"
            fill="none"
          />
        </svg>

        {/* Driver car icon on route */}
        <div className="absolute" style={{ top: '35%', left: '45%' }}>
          <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center shadow-xl animate-pulse">
            <Navigation size={24} className="text-white transform rotate-45" />
          </div>
        </div>

        {/* Destination marker */}
        <div className="absolute" style={{ bottom: '30%', right: '20%' }}>
          <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center shadow-lg">
            <div className="w-3 h-3 bg-white rounded-full"></div>
          </div>
        </div>

        {/* Top Bar */}
        <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between">
          <IconButton variant="light" onClick={() => navigate('/')}>
            <ArrowLeft size={24} />
          </IconButton>
          <div className="flex gap-2">
            <IconButton variant="light">
              <Shield size={24} />
            </IconButton>
            <IconButton variant="light">
              <MoreVertical size={24} />
            </IconButton>
          </div>
        </div>

        {/* ETA Banner */}
        <div className="absolute top-20 left-4 right-4 bg-white rounded-xl p-4 shadow-lg max-w-md mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Arriving in</p>
              <p className="text-2xl text-black">3 min</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Distance</p>
              <p className="text-lg text-black">0.8 mi</p>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-gray-200">
            <p className="text-sm text-black">Downtown Convention Center</p>
            <p className="text-xs text-gray-500">789 Congress Ave</p>
          </div>
        </div>

        {/* Safety Button - Floating */}
        <div className="absolute bottom-80 right-4">
          <button className="w-14 h-14 bg-white rounded-full shadow-xl flex items-center justify-center hover:scale-105 transition-transform">
            <Shield size={24} className="text-black" />
          </button>
        </div>
      </div>

      {/* Driver Info Card */}
      <div className="max-w-md mx-auto w-full">
        <DriverCard {...driverInfo} />
      </div>
    </div>
  );
}
