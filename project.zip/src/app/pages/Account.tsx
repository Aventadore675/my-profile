import React from 'react';
import { User, CreditCard, Shield, Bell, HelpCircle, Gift, Star, ChevronRight, Settings } from 'lucide-react';
import { BottomNav } from '../components/molecules/BottomNav';

interface MenuItem {
  id: string;
  icon: any;
  title: string;
  subtitle?: string;
  badge?: string;
}

const menuSections = [
  {
    title: 'Account',
    items: [
      { id: 'profile', icon: User, title: 'Profile', subtitle: 'John Smith' },
      { id: 'payment', icon: CreditCard, title: 'Payment methods', subtitle: '•••• 4242' },
      { id: 'promotions', icon: Gift, title: 'Promotions', badge: '2 available' }
    ]
  },
  {
    title: 'Preferences',
    items: [
      { id: 'notifications', icon: Bell, title: 'Notifications' },
      { id: 'privacy', icon: Shield, title: 'Privacy & security' },
      { id: 'settings', icon: Settings, title: 'Settings' }
    ]
  },
  {
    title: 'Support',
    items: [
      { id: 'help', icon: HelpCircle, title: 'Help' },
      { id: 'rate', icon: Star, title: 'Rate us' }
    ]
  }
];

export default function Account() {
  return (
    <div className="h-screen w-full bg-white flex flex-col font-['Inter']">
      <div className="flex-1 overflow-y-auto pb-24 max-w-md mx-auto w-full">
        {/* Header */}
        <div className="bg-white border-b border-gray-100 p-6">
          <h1 className="text-2xl text-black mb-4">Account</h1>
          
          {/* User Profile Card */}
          <div className="bg-gray-50 rounded-2xl p-4 flex items-center gap-4">
            <div className="w-16 h-16 bg-black rounded-full flex items-center justify-center text-white text-xl">
              JS
            </div>
            <div className="flex-1">
              <h2 className="text-black">John Smith</h2>
              <p className="text-sm text-gray-600">john.smith@email.com</p>
              <div className="flex items-center gap-1 mt-1">
                <Star size={14} className="text-black fill-black" />
                <span className="text-sm text-black">4.92</span>
                <span className="text-sm text-gray-500">• 127 trips</span>
              </div>
            </div>
          </div>
        </div>

        {/* Menu Sections */}
        <div className="p-6 space-y-6">
          {menuSections.map((section) => (
            <div key={section.title}>
              <h3 className="text-sm text-gray-600 mb-3">{section.title}</h3>
              <div className="space-y-2">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      className="w-full bg-white border border-gray-100 rounded-xl p-4 flex items-center gap-4 hover:bg-gray-50 transition-all active:scale-[0.99]"
                    >
                      <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Icon size={20} className="text-black" />
                      </div>
                      
                      <div className="flex-1 text-left">
                        <p className="text-black">{item.title}</p>
                        {item.subtitle && (
                          <p className="text-sm text-gray-600">{item.subtitle}</p>
                        )}
                      </div>

                      {item.badge && (
                        <span className="px-2 py-1 bg-black text-white text-xs rounded-full">
                          {item.badge}
                        </span>
                      )}
                      
                      <ChevronRight size={20} className="text-gray-400" />
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Sign Out Button */}
          <button className="w-full bg-white border border-gray-200 rounded-xl p-4 text-red-600 hover:bg-red-50 transition-all">
            Sign out
          </button>
        </div>
      </div>
      <BottomNav />
    </div>
  );
}