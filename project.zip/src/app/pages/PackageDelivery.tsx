import React, { useState } from 'react';
import { ArrowLeft, MapPin, Package as PackageIcon, User } from 'lucide-react';
import { useNavigate } from 'react-router';
import { IconButton } from '../components/atoms/IconButton';
import { PrimaryButton } from '../components/atoms/PrimaryButton';
import { BottomNav } from '../components/molecules/BottomNav';

interface PackageOption {
  id: string;
  name: string;
  description: string;
  size: string;
  eta: string;
  price: number;
}

const packageOptions: PackageOption[] = [
  {
    id: 'small',
    name: 'Small Package',
    description: 'Documents, small items',
    size: 'Up to 5 lbs',
    eta: '30 min',
    price: 8.50
  },
  {
    id: 'medium',
    name: 'Medium Package',
    description: 'Box, multiple items',
    size: 'Up to 20 lbs',
    eta: '45 min',
    price: 12.75
  },
  {
    id: 'large',
    name: 'Large Package',
    description: 'Bulky items, furniture',
    size: 'Up to 50 lbs',
    eta: '60 min',
    price: 18.99
  }
];

export default function PackageDelivery() {
  const navigate = useNavigate();
  const [selectedPackage, setSelectedPackage] = useState('small');
  const [step, setStep] = useState<'details' | 'options'>('details');

  const handleContinue = () => {
    if (step === 'details') {
      setStep('options');
    } else {
      navigate('/active-ride'); // Reuse the active ride page for package tracking
    }
  };

  return (
    <div className="h-screen w-full bg-white flex flex-col font-['Inter']">
      {/* Map Background - Smaller */}
      <div className="h-[40vh] relative bg-gradient-to-br from-gray-100 to-gray-200">
        {/* Simulated Map */}
        <div className="absolute inset-0 opacity-30">
          <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <pattern id="grid3" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="gray" strokeWidth="0.5"/>
            </pattern>
            <rect width="100%" height="100%" fill="url(#grid3)" />
          </svg>
        </div>

        {/* Route line visualization if on options step */}
        {step === 'options' && (
          <>
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              <path
                d="M 50 80 Q 120 150, 300 200"
                stroke="black"
                strokeWidth="3"
                fill="none"
                strokeDasharray="8,4"
              />
            </svg>

            {/* Start and End markers */}
            <div className="absolute" style={{ top: '20%', left: '15%' }}>
              <div className="w-3 h-3 bg-black rounded-full"></div>
            </div>
            <div className="absolute" style={{ top: '55%', right: '20%' }}>
              <div className="w-10 h-10 bg-black rounded-full flex items-center justify-center shadow-lg">
                <MapPin size={20} className="text-white" />
              </div>
            </div>
          </>
        )}

        {/* Top Bar */}
        <div className="absolute top-0 left-0 right-0 p-4">
          <IconButton variant="light" onClick={() => navigate('/')}>
            <ArrowLeft size={24} />
          </IconButton>
        </div>
      </div>

      {/* Bottom Sheet */}
      <div className="flex-1 bg-white rounded-t-3xl -mt-6 shadow-2xl p-6 overflow-y-auto max-w-md mx-auto w-full pb-24">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center">
            <PackageIcon size={24} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl text-black">Send a package</h1>
            <p className="text-sm text-gray-600">Same-day delivery</p>
          </div>
        </div>

        {step === 'details' ? (
          <>
            {/* Pickup and Dropoff */}
            <div className="space-y-4 mb-6">
              <div className="bg-gray-50 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <div className="flex flex-col items-center gap-2 mt-1">
                    <div className="w-2 h-2 bg-black rounded-full"></div>
                    <div className="w-0.5 h-8 bg-gray-300"></div>
                    <MapPin size={16} className="text-black" />
                  </div>
                  <div className="flex-1">
                    <div className="mb-4">
                      <label className="text-xs text-gray-600 mb-1 block">Pickup location</label>
                      <input
                        type="text"
                        placeholder="Enter pickup address"
                        defaultValue="123 Main Street"
                        className="w-full bg-white rounded-lg px-3 py-2 text-black placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-black"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-600 mb-1 block">Dropoff location</label>
                      <input
                        type="text"
                        placeholder="Enter dropoff address"
                        defaultValue="456 Office Plaza"
                        className="w-full bg-white rounded-lg px-3 py-2 text-black placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-black"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Recipient Info */}
            <div className="mb-6">
              <h3 className="text-sm text-gray-600 mb-3">Recipient information</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                  <User size={20} className="text-gray-600" />
                  <input
                    type="text"
                    placeholder="Recipient name"
                    className="flex-1 bg-transparent text-black placeholder-gray-400 focus:outline-none"
                  />
                </div>
                <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
                  <span className="text-gray-600">📱</span>
                  <input
                    type="tel"
                    placeholder="Phone number"
                    className="flex-1 bg-transparent text-black placeholder-gray-400 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Package Details */}
            <div className="mb-6">
              <h3 className="text-sm text-gray-600 mb-3">Package details (optional)</h3>
              <textarea
                placeholder="Describe your package, special instructions..."
                rows={3}
                className="w-full bg-gray-50 rounded-xl p-4 text-black placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-black resize-none"
              />
            </div>

            {/* Info Banner */}
            <div className="mb-6 p-4 bg-blue-50 rounded-xl border border-blue-100">
              <div className="flex items-start gap-3">
                <span className="text-xl">💡</span>
                <div>
                  <p className="text-sm text-blue-900">Track your package in real-time</p>
                  <p className="text-xs text-blue-700 mt-1">Get live updates and share tracking with recipient</p>
                </div>
              </div>
            </div>

            <PrimaryButton onClick={handleContinue}>
              Continue
            </PrimaryButton>
          </>
        ) : (
          <>
            {/* Package Size Options */}
            <h2 className="text-black mb-4">Choose package size</h2>
            
            <div className="space-y-3 mb-6">
              {packageOptions.map((option) => (
                <button
                  key={option.id}
                  onClick={() => setSelectedPackage(option.id)}
                  className={`w-full p-4 rounded-xl border-2 transition-all text-left ${
                    selectedPackage === option.id
                      ? 'border-black bg-gray-50'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        selectedPackage === option.id ? 'bg-black' : 'bg-gray-100'
                      }`}>
                        <PackageIcon size={20} className={selectedPackage === option.id ? 'text-white' : 'text-gray-600'} />
                      </div>
                      <div>
                        <h3 className="text-black">{option.name}</h3>
                        <p className="text-sm text-gray-600">{option.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-black">${option.price.toFixed(2)}</p>
                      <p className="text-xs text-gray-500">{option.eta}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">{option.size}</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Payment Method */}
            <div className="mb-6 p-4 bg-gray-50 rounded-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                    <span className="text-lg">💳</span>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Payment</p>
                    <p className="text-black">•••• 4242</p>
                  </div>
                </div>
                <button className="text-sm text-gray-600 underline">Change</button>
              </div>
            </div>

            {/* Request Button */}
            <PrimaryButton onClick={handleContinue}>
              Request {packageOptions.find(p => p.id === selectedPackage)?.name}
            </PrimaryButton>
          </>
        )}
      </div>

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  );
}