import React, { useState } from 'react';
import { ArrowLeft, Star, Clock, Info, Plus, Minus, ShoppingBag } from 'lucide-react';
import { useNavigate } from 'react-router';
import { IconButton } from '../components/atoms/IconButton';
import { PrimaryButton } from '../components/atoms/PrimaryButton';

interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
}

const menuItems: MenuItem[] = [
  {
    id: '1',
    name: 'Classic Burger',
    description: 'Angus beef, lettuce, tomato, special sauce',
    price: 12.99,
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop',
    category: 'Burgers'
  },
  {
    id: '2',
    name: 'Cheese Burger',
    description: 'Double cheese, beef patty, pickles',
    price: 14.99,
    image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=400&h=300&fit=crop',
    category: 'Burgers'
  },
  {
    id: '3',
    name: 'French Fries',
    description: 'Crispy golden fries with sea salt',
    price: 4.99,
    image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400&h=300&fit=crop',
    category: 'Sides'
  },
  {
    id: '4',
    name: 'Onion Rings',
    description: 'Beer-battered crispy onion rings',
    price: 5.99,
    image: 'https://images.unsplash.com/photo-1639024471283-03518883512d?w=400&h=300&fit=crop',
    category: 'Sides'
  },
  {
    id: '5',
    name: 'Milkshake',
    description: 'Vanilla, chocolate, or strawberry',
    price: 5.49,
    image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=400&h=300&fit=crop',
    category: 'Drinks'
  },
  {
    id: '6',
    name: 'Soda',
    description: 'Coca-Cola, Sprite, or Fanta',
    price: 2.99,
    image: 'https://images.unsplash.com/photo-1581006852262-e4307cf6283a?w=400&h=300&fit=crop',
    category: 'Drinks'
  }
];

export default function RestaurantDetail() {
  const navigate = useNavigate();
  const [cart, setCart] = useState<{ [key: string]: number }>({});
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Burgers', 'Sides', 'Drinks'];

  const addToCart = (itemId: string) => {
    setCart(prev => ({
      ...prev,
      [itemId]: (prev[itemId] || 0) + 1
    }));
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => {
      const newCart = { ...prev };
      if (newCart[itemId] > 1) {
        newCart[itemId]--;
      } else {
        delete newCart[itemId];
      }
      return newCart;
    });
  };

  const cartTotal = Object.entries(cart).reduce((total, [itemId, quantity]) => {
    const item = menuItems.find(i => i.id === itemId);
    return total + (item?.price || 0) * quantity;
  }, 0);

  const cartItemCount = Object.values(cart).reduce((sum, count) => sum + count, 0);

  const filteredItems = selectedCategory === 'All' 
    ? menuItems 
    : menuItems.filter(item => item.category === selectedCategory);

  return (
    <div className="h-screen w-full bg-white flex flex-col font-['Inter']">
      {/* Restaurant Header Image */}
      <div className="relative h-48 bg-gradient-to-br from-gray-100 to-gray-200">
        <img
          src="https://images.unsplash.com/photo-1550547660-d9450f859349?w=800&h=400&fit=crop"
          alt="Restaurant"
          className="w-full h-full object-cover"
        />
        
        {/* Top Bar */}
        <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between">
          <IconButton variant="light" onClick={() => navigate('/food-delivery')}>
            <ArrowLeft size={24} />
          </IconButton>
          <IconButton variant="light">
            <Info size={24} />
          </IconButton>
        </div>
      </div>

      {/* Restaurant Info */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="p-4 max-w-md mx-auto w-full">
          <h1 className="text-2xl text-black mb-1">The Burger Place</h1>
          <p className="text-sm text-gray-600 mb-2">American, Burgers</p>
          
          <div className="flex items-center gap-4 text-sm mb-3">
            <div className="flex items-center gap-1">
              <Star size={16} className="text-black fill-black" />
              <span className="text-black">4.8</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock size={16} className="text-gray-600" />
              <span className="text-gray-600">20-30 min</span>
            </div>
            <div className="text-gray-600">$2.99 delivery</div>
          </div>

          <div className="bg-gray-50 rounded-lg p-3 flex items-start gap-2">
            <Info size={16} className="text-gray-600 mt-0.5" />
            <p className="text-sm text-gray-700">Free delivery on orders over $20</p>
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="bg-white border-b border-gray-100 sticky top-[220px] z-10">
        <div className="max-w-md mx-auto w-full px-4 py-3">
          <div className="flex gap-3 overflow-x-auto scrollbar-hide">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`flex-shrink-0 px-4 py-2 rounded-full transition-all ${
                  selectedCategory === category
                    ? 'bg-black text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="flex-1 overflow-y-auto pb-32">
        <div className="max-w-md mx-auto w-full p-4">
          <div className="space-y-4">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-xl border border-gray-100 overflow-hidden"
              >
                <div className="flex gap-4 p-4">
                  <div className="flex-1">
                    <h3 className="text-black mb-1">{item.name}</h3>
                    <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                    <p className="text-black">${item.price.toFixed(2)}</p>
                  </div>
                  <div className="relative w-24 h-24 rounded-lg overflow-hidden flex-shrink-0">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                {/* Add to Cart Controls */}
                <div className="px-4 pb-4">
                  {cart[item.id] ? (
                    <div className="flex items-center justify-between bg-black rounded-lg px-4 py-2">
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-white hover:opacity-80 transition-opacity"
                      >
                        <Minus size={20} />
                      </button>
                      <span className="text-white">{cart[item.id]}</span>
                      <button
                        onClick={() => addToCart(item.id)}
                        className="text-white hover:opacity-80 transition-opacity"
                      >
                        <Plus size={20} />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => addToCart(item.id)}
                      className="w-full bg-gray-100 hover:bg-gray-200 text-black rounded-lg px-4 py-2 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                    >
                      <Plus size={20} />
                      Add to cart
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Cart Footer */}
      {cartItemCount > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 shadow-lg z-20">
          <div className="max-w-md mx-auto w-full">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <ShoppingBag size={20} className="text-black" />
                <span className="text-black">{cartItemCount} items</span>
              </div>
              <span className="text-black text-lg">${cartTotal.toFixed(2)}</span>
            </div>
            <PrimaryButton onClick={() => navigate('/active-ride')}>
              View cart
            </PrimaryButton>
          </div>
        </div>
      )}
    </div>
  );
}
