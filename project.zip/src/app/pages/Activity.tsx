import React from 'react';
import { Car, UtensilsCrossed, Package, MapPin, Clock } from 'lucide-react';
import { BottomNav } from '../components/molecules/BottomNav';

interface Trip {
  id: string;
  type: 'ride' | 'food' | 'package';
  title: string;
  destination: string;
  date: string;
  time: string;
  price: number;
  status: 'completed' | 'cancelled';
}

const trips: Trip[] = [
  {
    id: '1',
    type: 'ride',
    title: 'UberX',
    destination: 'Downtown Convention Center',
    date: 'Today',
    time: '2:30 PM',
    price: 12.50,
    status: 'completed'
  },
  {
    id: '2',
    type: 'food',
    title: 'The Burger Place',
    destination: '123 Main Street',
    date: 'Yesterday',
    time: '7:45 PM',
    price: 28.99,
    status: 'completed'
  },
  {
    id: '3',
    type: 'ride',
    title: 'Comfort',
    destination: 'Airport Terminal 2',
    date: 'Feb 17',
    time: '6:00 AM',
    price: 45.75,
    status: 'completed'
  },
  {
    id: '4',
    type: 'package',
    title: 'Small Package',
    destination: '456 Office Plaza',
    date: 'Feb 15',
    time: '3:15 PM',
    price: 8.50,
    status: 'completed'
  },
  {
    id: '5',
    type: 'ride',
    title: 'UberX',
    destination: 'Shopping Mall',
    date: 'Feb 14',
    time: '1:20 PM',
    price: 15.25,
    status: 'completed'
  }
];

const iconMap = {
  ride: Car,
  food: UtensilsCrossed,
  package: Package
};

export default function Activity() {
  return (
    <div className="h-screen w-full bg-white flex flex-col font-['Inter']">
      <div className="flex-1 overflow-y-auto pb-24 max-w-md mx-auto w-full">
        {/* Header */}
        <div className="sticky top-0 bg-white z-10 border-b border-gray-100 p-6 pb-4">
          <h1 className="text-2xl text-black mb-2">Activity</h1>
          <p className="text-sm text-gray-600">Your recent trips and orders</p>
        </div>

        {/* Filters */}
        <div className="px-6 py-4 border-b border-gray-100">
          <div className="flex gap-3 overflow-x-auto scrollbar-hide">
            <button className="flex-shrink-0 px-4 py-2 rounded-full bg-black text-white">
              All
            </button>
            <button className="flex-shrink-0 px-4 py-2 rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200">
              Rides
            </button>
            <button className="flex-shrink-0 px-4 py-2 rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200">
              Food
            </button>
            <button className="flex-shrink-0 px-4 py-2 rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200">
              Package
            </button>
          </div>
        </div>

        {/* Trip List */}
        <div className="p-6 space-y-4">
          {trips.map((trip) => {
            const Icon = iconMap[trip.type];
            return (
              <button
                key={trip.id}
                className="w-full bg-white border border-gray-100 rounded-xl p-4 text-left hover:shadow-md transition-all active:scale-[0.99]"
              >
                <div className="flex items-start gap-4">
                  {/* Icon */}
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon size={20} className="text-black" />
                  </div>

                  {/* Trip Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="text-black">{trip.title}</h3>
                        <div className="flex items-center gap-1 text-sm text-gray-600 mt-1">
                          <MapPin size={14} />
                          <span className="truncate">{trip.destination}</span>
                        </div>
                      </div>
                      <p className="text-black text-right">${trip.price.toFixed(2)}</p>
                    </div>

                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        <Clock size={12} />
                        <span>{trip.date} • {trip.time}</span>
                      </div>
                      <span className="px-2 py-1 bg-green-50 text-green-700 rounded-full">
                        Completed
                      </span>
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
      <BottomNav />
    </div>
  );
}