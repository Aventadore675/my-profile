import { RouterProvider } from 'react-router';
import { router } from './routes';

export default function App() {
  return (
    <div className="w-full min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="w-full max-w-[430px] h-screen bg-white overflow-hidden shadow-xl">
        <RouterProvider router={router} />
      </div>
    </div>
  );
}