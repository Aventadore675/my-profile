import { createBrowserRouter } from 'react-router';
import Home from './pages/Home';
import RideSelection from './pages/RideSelection';
import ActiveRide from './pages/ActiveRide';
import Activity from './pages/Activity';
import Account from './pages/Account';
import FoodDelivery from './pages/FoodDelivery';
import PackageDelivery from './pages/PackageDelivery';
import RestaurantDetail from './pages/RestaurantDetail';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Home,
  },
  {
    path: '/ride-selection',
    Component: RideSelection,
  },
  {
    path: '/food-delivery',
    Component: FoodDelivery,
  },
  {
    path: '/restaurant-detail',
    Component: RestaurantDetail,
  },
  {
    path: '/package-delivery',
    Component: PackageDelivery,
  },
  {
    path: '/active-ride',
    Component: ActiveRide,
  },
  {
    path: '/activity',
    Component: Activity,
  },
  {
    path: '/account',
    Component: Account,
  },
]);