import React from 'react';
import { Car, UtensilsCrossed, Package } from 'lucide-react';
import { useNavigate } from 'react-router';

interface ServiceCardProps {
  id: string;
  name: string;
  description: string;
}

const iconMap = {
  ride: Car,
  food: UtensilsCrossed,
  package: Package
};

const routeMap = {
  ride: '/ride-selection',
  food: '/food-delivery',
  package: '/package-delivery'
};

export function ServiceCard({ id, name, description }: ServiceCardProps) {
  const navigate = useNavigate();
  const Icon = iconMap[id as keyof typeof iconMap] || Car;

  const handleClick = () => {
    const route = routeMap[id as keyof typeof routeMap];
    if (route) {
      navigate(route);
    }
  };

  return (
    <button 
      onClick={handleClick}
      className="bg-gray-50 rounded-xl p-6 text-left transition-all duration-200 hover:bg-gray-100 active:scale-[0.98]"
    >
      <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center mb-3">
        <Icon size={24} className="text-white" />
      </div>
      <h3 className="text-black mb-1">{name}</h3>
      <p className="text-sm text-gray-600">{description}</p>
    </button>
  );
}