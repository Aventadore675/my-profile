import React from 'react';
import { Home, Clock, User } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router';

export function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { id: 'home', label: 'Home', icon: Home, path: '/' },
    { id: 'activity', label: 'Activity', icon: Clock, path: '/activity' },
    { id: 'account', label: 'Account', icon: User, path: '/account' }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 safe-area-inset-bottom">
      <div className="max-w-md mx-auto flex items-center justify-around px-2 py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <button
              key={item.id}
              onClick={() => navigate(item.path)}
              className={`
                flex flex-col items-center justify-center py-2 px-4 rounded-lg min-w-[80px]
                transition-colors duration-200
                ${isActive ? 'text-black' : 'text-gray-500'}
              `}
            >
              <Icon size={24} strokeWidth={isActive ? 2 : 1.5} />
              <span className="text-xs mt-1">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
