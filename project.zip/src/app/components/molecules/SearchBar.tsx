import React from 'react';
import { Search } from 'lucide-react';
import { useNavigate } from 'react-router';

interface SearchBarProps {
  placeholder?: string;
  onClick?: () => void;
}

export function SearchBar({ 
  placeholder = 'Where to?',
  onClick 
}: SearchBarProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    if (onClick) {
      onClick();
    } else {
      navigate('/ride-selection');
    }
  };

  return (
    <button
      onClick={handleClick}
      className="w-full bg-white rounded-xl p-4 shadow-lg flex items-center gap-4 text-left transition-all duration-200 active:scale-[0.99]"
    >
      <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
        <Search size={20} className="text-black" />
      </div>
      <span className="text-gray-900">{placeholder}</span>
    </button>
  );
}
