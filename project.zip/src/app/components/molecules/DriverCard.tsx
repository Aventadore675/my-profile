import React from 'react';
import { Star, MessageCircle, Phone } from 'lucide-react';
import { IconButton } from '../atoms/IconButton';

interface DriverCardProps {
  name: string;
  rating: number;
  carModel: string;
  carColor: string;
  licensePlate: string;
  photo: string;
}

export function DriverCard({ 
  name, 
  rating, 
  carModel, 
  carColor, 
  licensePlate,
  photo 
}: DriverCardProps) {
  return (
    <div className="bg-white rounded-t-3xl shadow-2xl p-6">
      <div className="flex items-center gap-4 mb-4">
        <img 
          src={photo} 
          alt={name}
          className="w-16 h-16 rounded-full object-cover"
        />
        <div className="flex-1">
          <h3 className="text-black mb-1">{name}</h3>
          <div className="flex items-center gap-1 text-sm">
            <Star size={16} className="fill-black" />
            <span className="text-black">{rating.toFixed(2)}</span>
          </div>
        </div>
        <div className="flex gap-2">
          <IconButton variant="light">
            <MessageCircle size={20} />
          </IconButton>
          <IconButton variant="light">
            <Phone size={20} />
          </IconButton>
        </div>
      </div>
      
      <div className="bg-gray-50 rounded-xl p-4">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-gray-600">Vehicle</span>
          <span className="text-black">{carColor} {carModel}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">License Plate</span>
          <span className="text-black">{licensePlate}</span>
        </div>
      </div>
      
      <div className="mt-4 text-center">
        <p className="text-sm text-gray-600">Your driver is arriving</p>
        <p className="text-2xl text-black mt-1">3 min</p>
      </div>
    </div>
  );
}
