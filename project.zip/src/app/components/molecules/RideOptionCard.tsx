import React from 'react';
import { User } from 'lucide-react';

interface RideOptionCardProps {
  name: string;
  description: string;
  passengers: number;
  eta: string;
  price: number;
  isSelected?: boolean;
  onClick?: () => void;
}

export function RideOptionCard({ 
  name, 
  description, 
  passengers, 
  eta, 
  price, 
  isSelected = false,
  onClick 
}: RideOptionCardProps) {
  return (
    <button
      onClick={onClick}
      className={`
        w-full p-4 rounded-xl flex items-center gap-4 text-left transition-all duration-200
        ${isSelected ? 'bg-gray-100 ring-2 ring-black' : 'bg-white hover:bg-gray-50'}
        active:scale-[0.99]
      `}
    >
      <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
        <div className="text-2xl">🚗</div>
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <h4 className="text-black">{name}</h4>
          <div className="flex items-center gap-1 text-gray-600">
            <User size={14} />
            <span className="text-xs">{passengers}</span>
          </div>
        </div>
        <p className="text-sm text-gray-600 truncate">{description}</p>
        <p className="text-xs text-gray-500 mt-1">{eta} away</p>
      </div>
      
      <div className="text-right flex-shrink-0">
        <p className="text-black">${price.toFixed(2)}</p>
      </div>
    </button>
  );
}
