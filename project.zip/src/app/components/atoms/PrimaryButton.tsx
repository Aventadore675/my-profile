import React from 'react';

interface PrimaryButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  fullWidth?: boolean;
  disabled?: boolean;
  className?: string;
}

export function PrimaryButton({ 
  children, 
  onClick, 
  fullWidth = true, 
  disabled = false,
  className = ''
}: PrimaryButtonProps) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`
        bg-black text-white py-4 px-6 rounded-lg
        transition-all duration-200
        disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed
        active:scale-[0.98]
        ${fullWidth ? 'w-full' : ''}
        ${className}
      `}
    >
      {children}
    </button>
  );
}
