import React from 'react';

interface IconButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'default' | 'light';
  className?: string;
}

export function IconButton({ 
  children, 
  onClick, 
  variant = 'default',
  className = '' 
}: IconButtonProps) {
  const baseClasses = 'w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200 active:scale-95';
  const variantClasses = variant === 'light' 
    ? 'bg-white shadow-md' 
    : 'bg-black text-white';

  return (
    <button
      onClick={onClick}
      className={`${baseClasses} ${variantClasses} ${className}`}
    >
      {children}
    </button>
  );
}
